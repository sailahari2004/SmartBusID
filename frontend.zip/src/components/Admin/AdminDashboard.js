// AdminDashboard.js - Clean & Advanced Version
import React, { useState } from 'react';
import Users from './Users';
import Approval from './Approval';
import NewPassApplications from './NewPassApplications';
import PassRenewals from './PassRenewals';
import './AdminDashboard.css';

function AdminDashboard() {
  const [activeTab, setActiveTab] = useState('users');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleLogout = () => {
    // Logout logic here
    alert('Logout successful!');
  };

  const menuItems = [
    { key: 'users', icon: '👥', label: 'User Management', component: <Users /> },
    { key: 'approval', icon: '✅', label: 'Approval System', component: <Approval /> },
    { key: 'newPass', icon: '🆕', label: 'New Applications', component: <NewPassApplications /> },
    { key: 'renewals', icon: '🔄', label: 'Pass Renewals', component: <PassRenewals /> },
  ];

  const getActiveComponent = () => {
    const item = menuItems.find(item => item.key === activeTab);
    return item ? item.component : <Users />;
  };

  return (
    <div className="admin-dashboard">
      {/* Sidebar Overlay */}
      {sidebarOpen && (
        <div 
          className="sidebar-overlay"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={`sidebar ${sidebarOpen ? 'open' : ''}`}>
        <div className="sidebar-header">
          <div className="admin-brand">
            <div className="brand-logo">🚌</div>
            <div className="brand-text">
              <h2>BusPass Admin</h2>
              <span>Management System</span>
            </div>
          </div>
          <button className="sidebar-close" onClick={() => setSidebarOpen(false)}>
            <i className="fas fa-times"></i>
          </button>
        </div>

        <nav className="sidebar-nav">
          {menuItems.map((item) => (
            <button
              key={item.key}
              className={`nav-item ${activeTab === item.key ? 'active' : ''}`}
              onClick={() => {
                setActiveTab(item.key);
                setSidebarOpen(false);
              }}
            >
              <span className="nav-icon">{item.icon}</span>
              <span className="nav-label">{item.label}</span>
              <div className="nav-indicator"></div>
            </button>
          ))}
        </nav>

        <div className="sidebar-footer">
          <div className="admin-profile">
            <img 
              src="https://ui-avatars.com/api/?name=Admin+User&background=667eea&color=fff&bold=true" 
              alt="Admin" 
            />
            <div className="profile-info">
              <span className="admin-name">Admin User</span>
              <span className="admin-role">System Administrator</span>
            </div>
          </div>
          <button className="logout-btn" onClick={handleLogout}>
            <i className="fas fa-sign-out-alt"></i>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="main-content">
        {/* Header */}
        <header className="admin-header">
          <div className="header-left">
            <button className="sidebar-toggle" onClick={() => setSidebarOpen(true)}>
              <i className="fas fa-bars"></i>
            </button>
            <div className="page-info">
              <h1>
                {menuItems.find(item => item.key === activeTab)?.label}
              </h1>
              <div className="breadcrumb">
                <span>Dashboard</span>
                <i className="fas fa-chevron-right"></i>
                <span>{menuItems.find(item => item.key === activeTab)?.label}</span>
              </div>
            </div>
          </div>

          
        </header>

        {/* Quick Stats Bar */}
       

        {/* Main Content Area */}
        <section className="content-section">
          <div className="content-card">
            {getActiveComponent()}
          </div>
        </section>
      </main>
    </div>
  );
}

export default AdminDashboard;