// PassRenewals.jsx
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Approval.css';

const PassRenewals = () => {
  const [renewals, setRenewals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [actionLoading, setActionLoading] = useState(null);

  useEffect(() => {
    fetchRenewals();
  }, []);

  const fetchRenewals = async () => {
    try {
      setLoading(true);
      setError('');
      const response = await axios.get('http://localhost:5000/api/admin/pending-renewals');
      
      if (response.data.success) {
        setRenewals(response.data.renewals);
      } else {
        setError(response.data.message || 'Failed to fetch renewal requests');
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to fetch renewal requests');
      console.error('Error fetching renewals:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (renewalId) => {
    try {
      setActionLoading(renewalId);
      const response = await axios.post(`http://localhost:5000/api/admin/approve-renewal/${renewalId}`);
      
      if (response.data.success) {
        alert('✅ Pass renewal approved successfully!');
        fetchRenewals();
      } else {
        alert(`❌ Approval failed: ${response.data.message}`);
      }
    } catch (err) {
      console.error('Error approving renewal:', err);
      alert(`❌ Failed to approve renewal: ${err.response?.data?.message || err.message}`);
    } finally {
      setActionLoading(null);
    }
  };

  const handleReject = async (renewalId) => {
    const reason = prompt('Please enter a reason for rejection:');
    if (reason === null || reason.trim() === '') {
      alert('Please provide a reason for rejection.');
      return;
    }
    
    try {
      setActionLoading(renewalId);
      const response = await axios.post(`http://localhost:5000/api/admin/reject-request/${renewalId}`, {
        reason: reason.trim()
      });
      
      if (response.data.success) {
        alert('✅ Renewal request rejected successfully!');
        fetchRenewals();
      } else {
        alert(`❌ Rejection failed: ${response.data.message}`);
      }
    } catch (err) {
      console.error('Error rejecting renewal:', err);
      alert(`❌ Failed to reject renewal: ${err.response?.data?.message || err.message}`);
    } finally {
      setActionLoading(null);
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    try {
      const date = new Date(dateString);
      return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch (error) {
      return 'Invalid Date';
    }
  };

  const getStatusBadge = (status) => {
    const statusConfig = {
      'pending': { class: 'status-pending', text: 'Pending Review' },
      'approved': { class: 'status-approved', text: 'Approved' },
      'rejected': { class: 'status-rejected', text: 'Rejected' }
    };
    
    const config = statusConfig[status] || statusConfig.pending;
    return <span className={`status ${config.class}`}>{config.text}</span>;
  };

  if (loading) {
    return (
      <div className="loading-container">
        <div className="loading-spinner"></div>
        <div className="loading-text">Loading renewal requests...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="error-container">
        <div className="error-message">
          <i className="fas fa-exclamation-triangle"></i>
          {error}
          <button className="retry-btn" onClick={fetchRenewals}>
            Try Again
          </button>
        </div>
      </div>
    );
  }

  const pendingRenewals = renewals.filter(renewal => renewal.status === 'pending');

  return (
    <div className="approval-container">
      <div className="approval-header">
        <div className="header-content">
          <h1>Pass Renewal Requests</h1>
          <p>Manage and review pass renewal requests from users</p>
        </div>
        <button className="refresh-btn" onClick={fetchRenewals} disabled={loading}>
          <i className="fas fa-sync-alt"></i>
          {loading ? 'Refreshing...' : 'Refresh'}
        </button>
      </div>

      <div className="stats-container">
        <div className="stat-card">
          <div className="stat-icon total">
            <i className="fas fa-sync-alt"></i>
          </div>
          <div className="stat-info">
            <span className="stat-number">{renewals.length}</span>
            <span className="stat-label">Total Renewal Requests</span>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon pending">
            <i className="fas fa-clock"></i>
          </div>
          <div className="stat-info">
            <span className="stat-number">{pendingRenewals.length}</span>
            <span className="stat-label">Pending Review</span>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon approved">
            <i className="fas fa-check-circle"></i>
          </div>
          <div className="stat-info">
            <span className="stat-number">
              {renewals.filter(r => r.status === 'approved').length}
            </span>
            <span className="stat-label">Approved</span>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon rejected">
            <i className="fas fa-times-circle"></i>
          </div>
          <div className="stat-info">
            <span className="stat-number">
              {renewals.filter(r => r.status === 'rejected').length}
            </span>
            <span className="stat-label">Rejected</span>
          </div>
        </div>
      </div>

      <div className="applications-container">
        {pendingRenewals.length > 0 ? (
          pendingRenewals.map(renewal => (
            <div key={renewal._id} className="application-card">
              <div className="card-header">
                <div className="applicant-info">
                  <img 
                    src={renewal.user_photo 
                      ? `http://localhost:5000/uploads/applicantPhotos/${renewal.user_photo}`
                      : `https://ui-avatars.com/api/?name=${renewal.user_name || 'User'}&background=0D8ABC&color=fff`
                    } 
                    alt={renewal.user_name} 
                    className="applicant-avatar"
                    onError={(e) => {
                      e.target.src = `https://ui-avatars.com/api/?name=${renewal.user_name || 'User'}&background=0D8ABC&color=fff`;
                    }}
                  />
                  <div className="applicant-details">
                    <h3>{renewal.user_name || 'No Name Provided'}</h3>
                    <p>{renewal.user_email || 'No Email Provided'}</p>
                    <span className="application-date">
                      Requested on {formatDate(renewal.requested_at)}
                    </span>
                  </div>
                </div>
                <div className="status-section">
                  {getStatusBadge(renewal.status)}
                  <div className="pass-code">Current Pass: {renewal.current_pass_code}</div>
                </div>
              </div>

              <div className="card-content">
                <div className="detail-row">
                  <div className="detail-item">
                    <span className="detail-label">Current Route</span>
                    <span className="detail-value route-info">
                      {renewal.current_from} → {renewal.current_to}
                    </span>
                  </div>
                  <div className="detail-item">
                    <span className="detail-label">Pass Type</span>
                    <span className="detail-value">{renewal.current_pass_type || 'N/A'}</span>
                  </div>
                  <div className="detail-item">
                    <span className="detail-label">Request Type</span>
                    <span className="detail-value">Pass Renewal</span>
                  </div>
                </div>
                
                <div className="renewal-note">
                  <i className="fas fa-info-circle"></i>
                  User is requesting to renew their current pass for another year.
                </div>
              </div>

              <div className="card-actions">
                <div className="action-buttons">
                  <button 
                    className="btn btn-danger"
                    onClick={() => handleReject(renewal._id)}
                    disabled={actionLoading === renewal._id}
                  >
                    <i className="fas fa-times"></i>
                    {actionLoading === renewal._id ? 'Processing...' : 'Reject'}
                  </button>
                  <button 
                    className="btn btn-success"
                    onClick={() => handleApprove(renewal._id)}
                    disabled={actionLoading === renewal._id}
                  >
                    <i className="fas fa-check"></i>
                    {actionLoading === renewal._id ? 'Processing...' : 'Approve Renewal'}
                  </button>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="empty-state">
            <div className="empty-icon">
              <i className="fas fa-sync-alt"></i>
            </div>
            <h3>No pending renewal requests</h3>
            <p>There are no pending renewal requests at this time.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default PassRenewals;