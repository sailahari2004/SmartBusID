// NewPassApplications.jsx - Fixed with proper headers
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Approval.css';

const NewPassApplications = () => {
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [actionLoading, setActionLoading] = useState(null);
  const [debugInfo, setDebugInfo] = useState('');

  // Create axios instance with default headers
  const api = axios.create({
    baseURL: 'http://localhost:5000',
    headers: {
      'Content-Type': 'application/json',
    },
  });

  // Add request interceptor to include auth token
  api.interceptors.request.use((config) => {
    const token = localStorage.getItem('adminToken') || localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  });

  useEffect(() => {
    fetchApplications();
  }, []);

  const fetchApplications = async () => {
    try {
      setLoading(true);
      setError('');
      console.log('🔄 Fetching new pass applications...');
      
      const response = await api.get('/api/admin/pending-new-pass-applications');
      
      console.log('📥 API Response:', response.data);
      
      if (response.data.success) {
        setApplications(response.data.applications);
        setDebugInfo(`Found ${response.data.applications.length} applications`);
      } else {
        setError(response.data.message || 'Failed to fetch applications');
      }
    } catch (err) {
      console.error('❌ Error fetching applications:', err);
      const errorMsg = err.response?.data?.message || 'Failed to fetch new pass applications';
      setError(errorMsg);
      setDebugInfo(`Error: ${errorMsg}`);
    } finally {
      setLoading(false);
    }
  };

  const debugApplications = async () => {
    try {
      console.log('🐛 Debugging applications...');
      const response = await api.get('/api/admin/debug-new-pass-applications');
      console.log('🐛 Debug response:', response.data);
      setDebugInfo(`Debug: ${response.data.total_applications} total apps in DB`);
    } catch (err) {
      console.error('Debug error:', err);
    }
  };

  const fixApplicationTypes = async () => {
    try {
      const response = await api.post('/api/admin/fix-application-types', {});
      alert(response.data.message);
      fetchApplications();
    } catch (err) {
      alert('Failed to fix application types');
    }
  };

  const handleApprove = async (applicationId) => {
    try {
      setActionLoading(applicationId);
      console.log(`✅ Approving application: ${applicationId}`);
      
      const response = await api.post(`/api/admin/approve-new-pass/${applicationId}`, {});
      
      console.log('📥 Approval response:', response.data);
      
      if (response.data.success) {
        alert(`✅ New pass application approved!\nNew Pass Code: ${response.data.new_pass_code}`);
        fetchApplications();
      } else {
        alert(`❌ Approval failed: ${response.data.message}`);
      }
    } catch (err) {
      console.error('❌ Error approving application:', err);
      console.error('Error details:', err.response?.data);
      alert(`❌ Failed to approve application: ${err.response?.data?.message || err.message}`);
    } finally {
      setActionLoading(null);
    }
  };

  const handleReject = async (applicationId) => {
    const reason = prompt('Please enter a reason for rejection:');
    if (reason === null || reason.trim() === '') {
      alert('Please provide a reason for rejection.');
      return;
    }
    
    try {
      setActionLoading(applicationId);
      const response = await api.post(`/api/admin/reject-request/${applicationId}`, {
        reason: reason.trim()
      });
      
      if (response.data.success) {
        alert('✅ New pass application rejected successfully!');
        fetchApplications();
      } else {
        alert(`❌ Rejection failed: ${response.data.message}`);
      }
    } catch (err) {
      console.error('❌ Error rejecting application:', err);
      console.error('Error details:', err.response?.data);
      alert(`❌ Failed to reject application: ${err.response?.data?.message || err.message}`);
    } finally {
      setActionLoading(null);
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    try {
      const date = new Date(dateString);
      return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch (error) {
      return 'Invalid Date';
    }
  };

  const getStatusBadge = (status) => {
    const statusConfig = {
      'pending': { class: 'status-pending', text: 'Pending Review' },
      'approved': { class: 'status-approved', text: 'Approved' },
      'rejected': { class: 'status-rejected', text: 'Rejected' }
    };
    
    const config = statusConfig[status] || statusConfig.pending;
    return <span className={`status ${config.class}`}>{config.text}</span>;
  };

  if (loading) {
    return (
      <div className="loading-container">
        <div className="loading-spinner"></div>
        <div className="loading-text">Loading new pass applications...</div>
      </div>
    );
  }

  return (
    <div className="approval-container">
      <div className="approval-header">
        <div className="header-content">
          <h1>New Pass Applications</h1>
          <p>Manage and review new pass applications with different routes</p>
          {debugInfo && (
            <div className="debug-info">
              <small>{debugInfo}</small>
            </div>
          )}
        </div>
        <div className="header-actions">
          <button className="btn btn-outline" onClick={debugApplications}>
            <i className="fas fa-bug"></i>
            Debug
          </button>
          <button className="btn btn-outline" onClick={fixApplicationTypes}>
            <i className="fas fa-wrench"></i>
            Fix Types
          </button>
          <button className="refresh-btn" onClick={fetchApplications} disabled={loading}>
            <i className="fas fa-sync-alt"></i>
            {loading ? 'Refreshing...' : 'Refresh'}
          </button>
        </div>
      </div>

      {error && (
        <div className="error-container">
          <div className="error-message">
            <i className="fas fa-exclamation-triangle"></i>
            {error}
            <button className="retry-btn" onClick={fetchApplications}>
              Try Again
            </button>
          </div>
        </div>
      )}

      <div className="stats-container">
        <div className="stat-card">
          <div className="stat-icon total">
            <i className="fas fa-plus-circle"></i>
          </div>
          <div className="stat-info">
            <span className="stat-number">{applications.length}</span>
            <span className="stat-label">Total Applications</span>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon pending">
            <i className="fas fa-clock"></i>
          </div>
          <div className="stat-info">
            <span className="stat-number">
              {applications.filter(a => a.status === 'pending').length}
            </span>
            <span className="stat-label">Pending Review</span>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon approved">
            <i className="fas fa-check-circle"></i>
          </div>
          <div className="stat-info">
            <span className="stat-number">
              {applications.filter(a => a.status === 'approved').length}
            </span>
            <span className="stat-label">Approved</span>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon rejected">
            <i className="fas fa-times-circle"></i>
          </div>
          <div className="stat-info">
            <span className="stat-number">
              {applications.filter(a => a.status === 'rejected').length}
            </span>
            <span className="stat-label">Rejected</span>
          </div>
        </div>
      </div>

      <div className="applications-container">
        {applications.length > 0 ? (
          applications.map(application => (
            <div key={application._id} className="application-card">
              <div className="card-header">
                <div className="applicant-info">
                  <img 
                    src={application.user_photo 
                      ? `http://localhost:5000/uploads/applicantPhotos/${application.user_photo}`
                      : `https://ui-avatars.com/api/?name=${application.user_name || 'User'}&background=0D8ABC&color=fff`
                    } 
                    alt={application.user_name} 
                    className="applicant-avatar"
                    onError={(e) => {
                      e.target.src = `https://ui-avatars.com/api/?name=${application.user_name || 'User'}&background=0D8ABC&color=fff`;
                    }}
                  />
                  <div className="applicant-details">
                    <h3>{application.user_name || 'No Name Provided'}</h3>
                    <p>{application.user_email || 'No Email Provided'}</p>
                    <span className="application-date">
                      Applied on {formatDate(application.applied_at)}
                    </span>
                    <small className="application-id">ID: {application._id}</small>
                  </div>
                </div>
                <div className="status-section">
                  {getStatusBadge(application.status)}
                  {application.current_pass_code && (
                    <div className="pass-code">Current Pass: {application.current_pass_code}</div>
                  )}
                </div>
              </div>

              <div className="card-content">
                <div className="detail-row">
                  <div className="detail-item">
                    <span className="detail-label">Requested Route</span>
                    <span className="detail-value route-info">
                      {application.from_location} → {application.to_location}
                    </span>
                  </div>
                  <div className="detail-item">
                    <span className="detail-label">Pass Type</span>
                    <span className="detail-value">{application.pass_type || 'N/A'}</span>
                  </div>
                  <div className="detail-item">
                    <span className="detail-label">Request Type</span>
                    <span className="detail-value">New Pass Application</span>
                  </div>
                </div>
                
                {application.current_from && application.current_to && (
                  <div className="detail-row">
                    <div className="detail-item">
                      <span className="detail-label">Current Route</span>
                      <span className="detail-value">
                        {application.current_from} → {application.current_to}
                      </span>
                    </div>
                    <div className="detail-item">
                      <span className="detail-label">Route Change</span>
                      <span className="detail-value route-change">
                        <i className="fas fa-arrow-right"></i>
                        Different Route Requested
                      </span>
                    </div>
                  </div>
                )}
              </div>

              <div className="card-actions">
                <div className="action-buttons">
                  <button 
                    className="btn btn-danger"
                    onClick={() => handleReject(application._id)}
                    disabled={actionLoading === application._id}
                  >
                    <i className="fas fa-times"></i>
                    {actionLoading === application._id ? 'Processing...' : 'Reject'}
                  </button>
                  <button 
                    className="btn btn-success"
                    onClick={() => handleApprove(application._id)}
                    disabled={actionLoading === application._id}
                  >
                    <i className="fas fa-check"></i>
                    {actionLoading === application._id ? 'Processing...' : 'Approve New Pass'}
                  </button>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="empty-state">
            <div className="empty-icon">
              <i className="fas fa-plus-circle"></i>
            </div>
            <h3>No pending new pass applications</h3>
            <p>There are no pending new pass applications at this time.</p>
            <div className="empty-actions">
              <button className="btn btn-outline" onClick={debugApplications}>
                <i className="fas fa-bug"></i>
                Debug Database
              </button>
              <button className="btn btn-outline" onClick={fixApplicationTypes}>
                <i className="fas fa-wrench"></i>
                Fix Application Types
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default NewPassApplications;