// Dashboard.js - Fixed Version
import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import './Dashboard.css';
import { useNavigate } from 'react-router-dom';
import { api } from '../../services/api';

const Dashboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [passInfo, setPassInfo] = useState(null);
  const [tripInfo, setTripInfo] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchUserData();
  }, []);

  const fetchUserData = async () => {
    try {
      setLoading(true);
      const [passResponse, tripResponse] = await Promise.all([
        api.get('/api/user/pass-info'),
        api.get('/api/user/trip-history')
      ]);

      if (passResponse.data.success) {
        setPassInfo(passResponse.data.user);
      }

      if (tripResponse.data.success) {
        setTripInfo(tripResponse.data);
      }
    } catch (error) {
      console.error('Error fetching user data:', error);
    } finally {
      setLoading(false);
    }
  };

  const calculateAge = (dob) => {
    if (!dob) return 'N/A';
    const birthDate = new Date(dob);
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  };

  const getDaysRemaining = (expiryDate) => {
    if (!expiryDate) return 0;
    const expiry = new Date(expiryDate);
    const today = new Date();
    const diffTime = expiry - today;
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  };

  if (loading) {
    return (
      <div className="dashboard-content">
        <div className="loading-spinner">
          <div className="spinner"></div>
          <p>Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  const daysRemaining = passInfo ? getDaysRemaining(passInfo.pass_expiry) : 0;
  const userAge = calculateAge(passInfo?.dob);

  return (
    <div className="dashboard-content">
      {/* Welcome Section */}
      <div className="welcome-section">
        <div className="welcome-content">
          <div className="welcome-text">
            <h1>Welcome back, {user?.name}!</h1>
            <p className="welcome-subtitle">Here's your travel overview</p>
          </div>
          {passInfo?.applicant_photo_filename && (
            <div className="avatar-container">
              <img 
                src={`http://localhost:5000/uploads/applicantPhotos/${passInfo.applicant_photo_filename}`} 
                alt="Profile" 
                className="user-avatar"
              />
            </div>
          )}
        </div>
      </div>

      {/* Stats Grid */}
      <div className="stats-grid">
        {/* Pass Status Card */}
        <div className="stat-card pass-status">
          <div className="card-header">
            <div className="card-icon">
              <i className="fas fa-ticket-alt"></i>
            </div>
            <h3>Pass Status</h3>
          </div>
          <div className="card-content">
            <div className={`status-badge ${passInfo?.Pass_Status ? 'active' : 'inactive'}`}>
              {passInfo?.Pass_Status ? 'ACTIVE' : 'INACTIVE'}
            </div>
            {passInfo?.pass_expiry && (
              <p className="expiry-date">
                Valid until: {new Date(passInfo.pass_expiry).toLocaleDateString()}
              </p>
            )}
            <button 
              className="card-btn primary"
              onClick={() => navigate("/pass")}
              disabled={!passInfo?.Pass_Status}
            >
              View Pass Details
            </button>
          </div>
        </div>

        {/* Trip Info Card */}
        <div className="stat-card trip-info">
          <div className="card-header">
            <div className="card-icon">
              <i className="fas fa-bus"></i>
            </div>
            <h3>Recent Trips</h3>
          </div>
          <div className="card-content">
            <div className="trip-count">
              <span className="count">{tripInfo?.total_trips || 0}</span>
              <span className="label">trips this week</span>
            </div>
            <div className="days-remaining">
              {daysRemaining > 0 ? (
                <span className="days-count">{daysRemaining} days remaining</span>
              ) : (
                <span className="expired">Pass expired</span>
              )}
            </div>
            <button 
              className="card-btn secondary"
              onClick={() => navigate("/history")}
            >
              View Trip History
            </button>
          </div>
        </div>

        {/* Route Info Card */}
        <div className="stat-card route-info">
          <div className="card-header">
            <div className="card-icon">
              <i className="fas fa-route"></i>
            </div>
            <h3>Travel Route</h3>
          </div>
          <div className="card-content">
            {passInfo?.From && passInfo?.To ? (
              <>
                <div className="route-display">
                  <span className="location from">{passInfo.From}</span>
                  <i className="fas fa-arrow-right"></i>
                  <span className="location to">{passInfo.To}</span>
                </div>
                <div className="pass-type">
                  {passInfo.pass_type} Pass
                </div>
                {userAge && (
                  <div className="user-age">
                    Age: {userAge} years
                  </div>
                )}
              </>
            ) : (
              <p className="no-route">No route configured</p>
            )}
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      
    </div>
  );
};

export default Dashboard;