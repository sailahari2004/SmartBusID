// TravelHistory.js
import React, { useState, useEffect } from 'react';
import { api, getUserTripHistory } from '../../services/api'; // Use the correct exports
import './TravelHistory.css';

const TravelHistory = () => {
  const [trips, setTrips] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchTravelHistory();
  }, []);

  const fetchTravelHistory = async () => {
    try {
      setLoading(true);
      setError('');
      
      // Option 1: Use the getUserTripHistory function if it exists
      // const response = await getUserTripHistory();
      
      // Option 2: Use the generic api instance
      const response = await api.get('/api/user/travel-history');
      
      if (response.data.success) {
        setTrips(response.data.trips || response.data.history || []);
      } else {
        setError(response.data.message || 'Failed to fetch travel history');
      }
    } catch (err) {
      console.error('Error fetching travel history:', err);
      setError(err.response?.data?.message || 'Failed to load travel history');
    } finally {
      setLoading(false);
    }
  };

  const exportToCSV = () => {
    if (trips.length === 0) return;
    
    const headers = ['Date', 'From', 'To', 'Distance (km)', 'Fare (₹)'];
    const csvData = trips.map(trip => [
      trip.date,
      trip.from,
      trip.to,
      trip.distance_km,
      trip.fare
    ]);
    
    const csvContent = [
      headers.join(','),
      ...csvData.map(row => row.join(','))
    ].join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `travel-history-${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    window.URL.revokeObjectURL(url);
  };

  if (loading) {
    return (
      <div className="history-content">
        <div className="history-card">
          <h2>Travel History</h2>
          <div className="loading-spinner">
            <div className="spinner"></div>
            <p>Loading travel history...</p>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="history-content">
        <div className="history-card">
          <h2>Travel History</h2>
          <div className="error-message">
            <i className="fas fa-exclamation-circle"></i>
            <p>{error}</p>
            <button className="btn primary" onClick={fetchTravelHistory}>
              Try Again
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="history-content">
      <div className="history-card">
        <div className="history-header">
          <h2>Travel History</h2>
          <button 
            className="btn secondary" 
            onClick={fetchTravelHistory}
            title="Refresh history"
          >
            <i className="fas fa-sync-alt"></i>
          </button>
        </div>
        
        <div className="table-wrap">
          {trips.length > 0 ? (
            <table className="history-table">
              <thead>
                <tr>
                  <th>Date</th>
                  <th>From</th>
                  <th>To</th>
                  
                </tr>
              </thead>
              <tbody>
                {trips.map((trip, index) => (
                  <tr key={trip._id || trip.id || index}>
                    <td>{new Date(trip.date).toLocaleDateString()}</td>
                    <td>{trip.from || trip.fromLocation || trip.From || 'N/A'}</td>
                    <td>{trip.to || trip.toLocation || trip.To || 'N/A'}</td>
                    
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <div className="no-data">
              <i className="fas fa-history"></i>
              <p>No travel history found</p>
            </div>
          )}
        </div>
        
        <div className="history-actions">
          <button 
            className="btn primary" 
            onClick={exportToCSV}
            disabled={trips.length === 0}
          >
            Export CSV
          </button>
        </div>
      </div>
    </div>
  );
};

export default TravelHistory;