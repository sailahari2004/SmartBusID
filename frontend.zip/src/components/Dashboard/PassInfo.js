// PassInfo.js - Updated for multiple passes
import React, { useState, useEffect } from 'react';
import './PassInfo.css';
import { api } from '../../services/api';
import { QRCodeSVG } from 'qrcode.react';

const PassInfo = () => {
  const [passes, setPasses] = useState([]);
  const [activePass, setActivePass] = useState(null);
  const [loading, setLoading] = useState(true);
  const [qrValue, setQrValue] = useState('');
  const [renewLoading, setRenewLoading] = useState(false);
  const [showNewPassForm, setShowNewPassForm] = useState(false);
  const [newPassData, setNewPassData] = useState({
    from: '',
    to: '',
    passType: 'student'
  });
  const [error, setError] = useState('');

  useEffect(() => {
    fetchPassInfo();
  }, []);

  const fetchPassInfo = async () => {
    try {
      setLoading(true);
      setError('');
      const response = await api.get('/api/user/pass-info');
      
      if (response.data.success) {
        console.log('📋 Pass info response:', response.data);
        
        // Handle both single pass and multiple passes
        if (response.data.passes && Array.isArray(response.data.passes)) {
          setPasses(response.data.passes);
          // Set the first active pass or the first pass as active
          const active = response.data.passes.find(pass => pass.Pass_Status) || response.data.passes[0];
          setActivePass(active);
          updateQRCode(active);
        } else if (response.data.user) {
          // Single pass format (backward compatibility)
          setPasses([response.data.user]);
          setActivePass(response.data.user);
          updateQRCode(response.data.user);
        } else {
          setError('No pass data found');
        }
      } else {
        setError(response.data.message || 'Failed to load pass information');
      }
    } catch (error) {
      console.error('Error fetching pass info:', error);
      setError('Failed to load pass information');
    } finally {
      setLoading(false);
    }
  };

  const updateQRCode = (pass) => {
    if (pass && pass.pass_code) {
      setQrValue(JSON.stringify({
        passId: pass.pass_code,
        userId: pass._id,
        name: pass.name,
        type: pass.pass_type,
        validUntil: pass.pass_expiry,
        photo: pass.applicant_photo_filename
      }));
    } else {
      setQrValue('');
    }
  };

  const handlePassSwitch = (pass) => {
    setActivePass(pass);
    updateQRCode(pass);
  };

  const calculateAge = (dob) => {
    if (!dob) return 'N/A';
    const birthDate = new Date(dob);
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    try {
      const date = new Date(dateString);
      return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      });
    } catch (error) {
      console.error('Error formatting date:', error);
      return 'Invalid Date';
    }
  };

  const downloadQRCode = () => {
    if (!activePass) return;
    
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    
    const svgElement = document.getElementById('qr-code-svg');
    if (!svgElement) return;
    
    const svgData = new XMLSerializer().serializeToString(svgElement);
    const svgBlob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(svgBlob);
    
    const img = new Image();
    img.onload = function() {
      canvas.width = img.width;
      canvas.height = img.height;
      ctx.drawImage(img, 0, 0);
      
      const pngUrl = canvas.toDataURL('image/png');
      let downloadLink = document.createElement('a');
      downloadLink.href = pngUrl;
      downloadLink.download = `bus-pass-${activePass.pass_code}.png`;
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);
      URL.revokeObjectURL(url);
    };
    img.src = url;
  };

  const handleRenewPass = async () => {
    if (!activePass) return;
    
    setRenewLoading(true);
    try {
      const response = await api.post('/api/user/renew-pass', {
        passId: activePass._id,
        currentPassCode: activePass.pass_code
      });

      if (response.data.success) {
        alert('Pass renewal request submitted successfully! The admin will review your request.');
        fetchPassInfo();
      } else {
        alert(response.data.message || 'Failed to submit renewal request');
      }
    } catch (error) {
      console.error('Error renewing pass:', error);
      alert('Error submitting renewal request. Please try again.');
    } finally {
      setRenewLoading(false);
    }
  };

  const handleApplyNewPass = async () => {
    if (!newPassData.from || !newPassData.to) {
      alert('Please fill in both From and To locations');
      return;
    }

    setRenewLoading(true);
    setError('');
    
    try {
      console.log('📤 Sending new pass application:', newPassData);
      
      const response = await api.post('/api/user/apply-new-pass', {
        from: newPassData.from,
        to: newPassData.to,
        passType: newPassData.passType
      });

      console.log('📥 Response received:', response.data);

      if (response.data.success) {
        alert('New pass application submitted successfully! The admin will review your request.');
        setShowNewPassForm(false);
        setNewPassData({ from: '', to: '', passType: 'student' });
        fetchPassInfo();
      } else {
        const errorMsg = response.data.message || 'Failed to submit new pass application';
        setError(errorMsg);
        alert(errorMsg);
      }
    } catch (error) {
      console.error('❌ Error applying for new pass:', error);
      
      let errorMessage = 'Error submitting new pass application. Please try again.';
      
      if (error.response) {
        errorMessage = error.response.data?.message || 
                      `Server error: ${error.response.status}`;
      } else if (error.request) {
        errorMessage = 'No response from server. Please check your connection.';
      }
      
      setError(errorMessage);
      alert(errorMessage);
    } finally {
      setRenewLoading(false);
    }
  };

  const getDaysUntilExpiry = (expiryDate) => {
    if (!expiryDate) return null;
    const today = new Date();
    const expiry = new Date(expiryDate);
    const diffTime = expiry - today;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const isPassExpired = (pass) => {
    if (!pass.pass_expiry) return true;
    const expiry = new Date(pass.pass_expiry);
    const today = new Date();
    return expiry < today;
  };

  if (loading) {
    return (
      <div className="dashboard-content">
        <div className="loading-spinner">
          <div className="spinner-container">
            <div className="spinner-circle"></div>
            <div className="spinner-orbiter">
              <div className="spinner-dot"></div>
              <div className="spinner-dot"></div>
              <div className="spinner-dot"></div>
              <div className="spinner-dot"></div>
            </div>
          </div>
          <p>Loading...</p>
        </div>
      </div>
    );
  }

  if (!passes || passes.length === 0) {
    return (
      <div className="passinfo-content">
        <div className="no-pass">
          <i className="fas fa-ticket-alt"></i>
          <h3>No Active Pass</h3>
          <p>You don't have an active bus pass yet.</p>
          <button 
            className="btn primary" 
            onClick={() => setShowNewPassForm(true)}
          >
            Apply for Pass
          </button>
        </div>
      </div>
    );
  }

  const userAge = calculateAge(activePass?.dob);

  return (
    <div className="passinfo-content">
      {/* Error Display */}
      {error && (
        <div className="error-banner">
          <i className="fas fa-exclamation-triangle"></i>
          {error}
          <button className="close-error" onClick={() => setError('')}>
            <i className="fas fa-times"></i>
          </button>
        </div>
      )}

      {/* New Pass Application Form Modal */}
      {showNewPassForm && (
        <div className="modal-overlay">
          <div className="modal-content">
            <div className="modal-header">
              <h3>Apply for New Pass</h3>
              <button 
                className="close-btn"
                onClick={() => setShowNewPassForm(false)}
                disabled={renewLoading}
              >
                &times;
              </button>
            </div>
            <div className="modal-body">
              <div className="form-group">
                <label>From Location *</label>
                <input
                  type="text"
                  value={newPassData.from}
                  onChange={(e) => setNewPassData({...newPassData, from: e.target.value})}
                  placeholder="Enter starting location (e.g., Srikakulam)"
                  disabled={renewLoading}
                  required
                />
              </div>
              <div className="form-group">
                <label>To Location *</label>
                <input
                  type="text"
                  value={newPassData.to}
                  onChange={(e) => setNewPassData({...newPassData, to: e.target.value})}
                  placeholder="Enter destination location (e.g., Rajam)"
                  disabled={renewLoading}
                  required
                />
              </div>
              <div className="form-group">
                <label>Pass Type</label>
                <select
                  value={newPassData.passType}
                  onChange={(e) => setNewPassData({...newPassData, passType: e.target.value})}
                  disabled={renewLoading}
                >
                  <option value="student">Student</option>
                  <option value="senior">Senior Citizen</option>
                  <option value="general">General</option>
                </select>
              </div>
              <div className="form-note">
                <p><strong>Note:</strong> Your current passes will remain active until the new pass is approved.</p>
              </div>
            </div>
            <div className="modal-actions">
              <button 
                className="btn outline"
                onClick={() => setShowNewPassForm(false)}
                disabled={renewLoading}
              >
                Cancel
              </button>
              <button 
                className="btn primary"
                onClick={handleApplyNewPass}
                disabled={renewLoading || !newPassData.from || !newPassData.to}
              >
                {renewLoading ? (
                  <>
                    <i className="fas fa-spinner fa-spin"></i>
                    Submitting...
                  </>
                ) : (
                  'Apply for New Pass'
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Pass Selection Tabs for Multiple Passes */}
      {passes.length > 1 && (
        <div className="pass-selection-tabs">
          <div className="tabs-header">
            <h3>Your Passes ({passes.length})</h3>
            <p>Select a pass to view details</p>
          </div>
          <div className="tabs-container">
            {passes.map((pass, index) => (
              <div
                key={pass._id}
                className={`pass-tab ${activePass?._id === pass._id ? 'active' : ''} ${
                  !pass.Pass_Status || isPassExpired(pass) ? 'expired' : ''
                }`}
                onClick={() => handlePassSwitch(pass)}
              >
                <div className="tab-content">
                  <div className="tab-route">
                    {pass.From} → {pass.To}
                  </div>
                  <div className="tab-details">
                    <span className="tab-type">{pass.pass_type}</span>
                    <span className={`tab-status ${
                      (pass.Pass_Status && !isPassExpired(pass)) ? 'active' : 'expired'
                    }`}>
                      {(pass.Pass_Status && !isPassExpired(pass)) ? 'Active' : 'Expired'}
                    </span>
                  </div>
                  {pass.pass_expiry && (
                    <div className="tab-expiry">
                      {isPassExpired(pass) ? 'Expired' : `Expires in ${getDaysUntilExpiry(pass.pass_expiry)} days`}
                    </div>
                  )}
                  <div className="tab-passcode">
                    Pass Code: {pass.pass_code || 'N/A'}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Main Pass Card */}
      {activePass && (
        <div className="pass-card">
          <div className="pass-header">
            <div className="header-left">
              <h2>Digital Bus Pass</h2>
              {passes.length > 1 && (
                <span className="pass-indicator">
                  Pass {passes.findIndex(p => p._id === activePass._id) + 1} of {passes.length}
                </span>
              )}
            </div>
            <span className={`status-badge ${
              (activePass.Pass_Status && !isPassExpired(activePass)) ? 'active' : 'expired'
            }`}>
              {(activePass.Pass_Status && !isPassExpired(activePass)) ? 'ACTIVE' : 'EXPIRED'}
            </span>
          </div>

          <div className="pass-content">
            <div className="pass-photo-section">
              {activePass.applicant_photo_filename && (
                <img 
                  src={`http://localhost:5000/uploads/applicantPhotos/${activePass.applicant_photo_filename}`} 
                  alt="Passenger" 
                  className="pass-photo"
                />
              )}
              <div className="pass-holder-info">
                <h3>{activePass.name}</h3>
                <p>{userAge} years • {activePass.gender}</p>
                <p className="pass-type">{activePass.pass_type}</p>
                {activePass.pass_expiry && (
                  <div className="expiry-warning">
                    <i className="fas fa-clock"></i>
                    {isPassExpired(activePass) ? (
                      <span className="warning-text">Expired on {formatDate(activePass.pass_expiry)}</span>
                    ) : (
                      <>
                        Expires on {formatDate(activePass.pass_expiry)}
                        {getDaysUntilExpiry(activePass.pass_expiry) <= 30 && (
                          <span className="warning-text"> (Renew soon!)</span>
                        )}
                      </>
                    )}
                  </div>
                )}
              </div>
            </div>

            <div className="pass-details-grid">
              <div className="pass-detail">
                <span className="label">Pass ID</span>
                <span className="value">{activePass.pass_code || 'N/A'}</span>
              </div>
              <div className="pass-detail">
                <span className="label">From</span>
                <span className="value">{activePass.From || 'N/A'}</span>
              </div>
              <div className="pass-detail">
                <span className="label">To</span>
                <span className="value">{activePass.To || 'N/A'}</span>
              </div>
              <div className="pass-detail">
                <span className="label">Issued On</span>
                <span className="value">
                  {formatDate(activePass.created_at)}
                </span>
              </div>
              <div className="pass-detail">
                <span className="label">Valid Until</span>
                <span className="value">
                  {formatDate(activePass.pass_expiry)}
                </span>
              </div>
              <div className="pass-detail">
                <span className="label">Status</span>
                <span className={`value status ${
                  (activePass.Pass_Status && !isPassExpired(activePass)) ? 'active' : 'expired'
                }`}>
                  {(activePass.Pass_Status && !isPassExpired(activePass)) ? 'Active' : 'Expired'}
                </span>
              </div>
            </div>

            <div className="qr-section">
              <div className="qr-code">
                {qrValue ? (
                  <>
                    <QRCodeSVG 
                      id="qr-code-svg"
                      value={qrValue} 
                      size={120}
                      level="H"
                      includeMargin={true}
                    />
                    <p>Scan this QR code</p>
                    <small>For route: {activePass.From} → {activePass.To}</small>
                  </>
                ) : (
                  <div className="qr-placeholder">
                    <i className="fas fa-qrcode"></i>
                    <p>QR code not available</p>
                  </div>
                )}
              </div>
              <div className="pass-notes">
                <p><strong>Terms & Conditions:</strong></p>
                <ul>
                  <li>Valid for travel between {activePass.From} and {activePass.To}</li>
                  <li>Non-transferable</li>
                  <li>Must be presented upon request</li>
                  {activePass.pass_expiry && (
                    <li>Valid until: {formatDate(activePass.pass_expiry)}</li>
                  )}
                </ul>
              </div>
            </div>
          </div>

          <div className="pass-actions">
            <button className="btn primary" onClick={downloadQRCode}>
              <i className="fas fa-download"></i>
              Download QR Code
            </button>
            <button 
              className="btn outline" 
              onClick={handleRenewPass}
              disabled={renewLoading || !activePass.Pass_Status || isPassExpired(activePass) || getDaysUntilExpiry(activePass.pass_expiry) > 30}
              title={
                isPassExpired(activePass) ? "This pass has expired" :
                getDaysUntilExpiry(activePass.pass_expiry) > 30 ? "You can renew within 30 days of expiry" :
                "Renew your pass"
              }
            >
              <i className="fas fa-sync-alt"></i>
              {renewLoading ? 'Processing...' : 'Renew Pass'}
            </button>
            <button 
              className="btn secondary"
              onClick={() => setShowNewPassForm(true)}
            >
              <i className="fas fa-plus"></i>
              Apply New Pass
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default PassInfo;