// Profile.js - Improved Styling Version
import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import './Profile.css';

const Profile = () => {
  const { user } = useAuth();
  const [profileData, setProfileData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [imageErrors, setImageErrors] = useState({
    applicant_photo: false,
    study_certificate: false
  });

  useEffect(() => {
    const loadProfileData = async () => {
      setLoading(true);
      setError(null);
      try {
        const token = localStorage.getItem('token');
        if (!token) {
          setError('No authentication token found');
          setLoading(false);
          return;
        }
        
        const response = await fetch(`http://localhost:5000/auth/profile`, {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          },
          credentials: 'include'
        });
        
        if (!response.ok) {
          const errorText = await response.text();
          let errorMessage = 'Failed to load profile data';
          
          try {
            const errorData = JSON.parse(errorText);
            errorMessage = errorData.message || errorMessage;
          } catch (e) {
            errorMessage = errorText || `HTTP ${response.status}`;
          }
          
          setError(errorMessage);
          return;
        }
        
        const data = await response.json();
        if (data.success) {
          setProfileData(data.user);
        } else {
          setError(data.message || 'Failed to load profile data');
        }
      } catch (error) {
        setError(`Network error: ${error.message}. Please check if the server is running.`);
      } finally {
        setLoading(false);
      }
    };

    if (user) {
      loadProfileData();
    } else {
      setLoading(false);
      setError('User information not available');
    }
  }, [user]);

  const formatDate = (dateString) => {
    if (!dateString || dateString === 'None') return 'Not specified';
    try {
      const options = { year: 'numeric', month: 'long', day: 'numeric' };
      return new Date(dateString).toLocaleDateString(undefined, options);
    } catch (error) {
      return dateString;
    }
  };

  const handleImageError = (imageType) => {
    setImageErrors(prev => ({
      ...prev,
      [imageType]: true
    }));
  };

  const getValue = (value) => {
    return value || 'Not provided';
  };

  // Check if section has meaningful data
  const hasPersonalInfo = (data) => {
    return data?.gender || data?.dob || data?.aadhar_number || data?.mobile_no;
  };

  const hasAddressInfo = (data) => {
    return data?.district || data?.mandal || data?.address;
  };

  const hasEducationInfo = (data) => {
    return data?.institution_name || data?.course_name || data?.present_course_year || data?.admission_number || data?.inst_address;
  };

  const hasPassInfo = (data) => {
    return data?.pass_type || data?.service_type || data?.renewal_frequency || data?.application_status || data?.created_at;
  };

  // Skeleton Loading Component
  const ProfileSkeleton = () => (
    <div className="profile-container">
      <div className="profile-header-skeleton">
        <div className="skeleton-header"></div>
      </div>
      
      <div className="profile-content">
        <div className="profile-card">
          <div className="profile-user-header-skeleton">
            <div className="avatar-skeleton"></div>
            <div className="user-info-skeleton">
              <div className="skeleton-line name"></div>
              <div className="skeleton-line email"></div>
            </div>
          </div>
          
          <div className="profile-details">
            {[1, 2, 3, 4].map(section => (
              <div key={section} className="profile-section-skeleton">
                <div className="section-title-skeleton"></div>
                <div className="details-grid-skeleton">
                  {[1, 2, 3].map(item => (
                    <div key={item} className="detail-item-skeleton">
                      <div className="label-skeleton"></div>
                      <div className="value-skeleton"></div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );

  if (loading) {
    return <ProfileSkeleton />;
  }

  if (error) {
    return (
      <div className="profile-container">
        <div className="error-container">
          <div className="error-content">
            <div className="error-icon">
              <i className="fas fa-exclamation-triangle"></i>
            </div>
            <h3>Unable to Load Profile</h3>
            <p>{error}</p>
            <button 
              className="btn-primary"
              onClick={() => window.location.reload()}
            >
              <i className="fas fa-redo"></i>
              Try Again
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (!profileData) {
    return (
      <div className="profile-container">
        <div className="error-container">
          <div className="error-content">
            <div className="error-icon">
              <i className="fas fa-user-slash"></i>
            </div>
            <h3>Profile Not Found</h3>
            <p>We couldn't find your profile information. Please check if you're logged in correctly.</p>
            <button 
              className="btn-primary"
              onClick={() => window.location.reload()}
            >
              <i className="fas fa-redo"></i>
              Reload Page
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="profile-container">
      {/* Header with Background Pattern */}
      <div className="profile-hero">
        <div className="hero-content">
          <h1>My Profile</h1>
          <p>personal information and bus pass details</p>
        </div>
        <div className="hero-pattern"></div>
      </div>
      
      {/* Main Content */}
      <div className="profile-content">
        <div className="profile-card">
          {/* User Profile Header */}
          <div className="profile-header">
            <div className="avatar-container">
              {profileData.applicant_photo_filename && !imageErrors.applicant_photo ? (
                <img 
                  src={`http://localhost:5000/uploads/applicantPhotos/${profileData.applicant_photo_filename}`} 
                  alt="Profile" 
                  className="profile-avatar"
                  onError={() => handleImageError('applicant_photo')}
                />
              ) : (
                <div className="avatar-placeholder">
                  <i className="fas fa-user"></i>
                </div>
              )}
              <div className="avatar-status"></div>
            </div>
            
            <div className="profile-info">
              <h2>{getValue(profileData.name)}</h2>
              <p className="profile-email">{getValue(profileData.email)}</p>
              <div className="profile-meta">
                <span className="meta-item">
                  <i className="fas fa-id-card"></i>
                  ID: {profileData._id?.substring(0, 8)}...
                </span>
                {profileData.application_status && (
                  <span className={`status-badge ${profileData.application_status.toLowerCase()}`}>
                    {profileData.application_status}
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Profile Details Sections */}
          <div className="profile-sections">
            {/* Personal Information */}
            {hasPersonalInfo(profileData) && (
              <div className="profile-section">
                <div className="section-header">
                  <div className="section-icon personal">
                    <i className="fas fa-user-circle"></i>
                  </div>
                  <h3>Personal Information</h3>
                </div>
                <div className="section-content">
                  <div className="info-grid">
                    {profileData.gender && (
                      <div className="info-item">
                        <label>Gender</label>
                        <div className="info-value">{profileData.gender}</div>
                      </div>
                    )}
                    {profileData.dob && profileData.dob !== 'None' && (
                      <div className="info-item">
                        <label>Date of Birth</label>
                        <div className="info-value">{formatDate(profileData.dob)}</div>
                      </div>
                    )}
                    {profileData.aadhar_number && (
                      <div className="info-item">
                        <label>Aadhar Number</label>
                        <div className="info-value aadhar">{profileData.aadhar_number}</div>
                      </div>
                    )}
                    {profileData.mobile_no && (
                      <div className="info-item">
                        <label>Mobile Number</label>
                        <div className="info-value phone">{profileData.mobile_no}</div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
            
            {/* Address Information */}
            {hasAddressInfo(profileData) && (
              <div className="profile-section">
                <div className="section-header">
                  <div className="section-icon address">
                    <i className="fas fa-map-marker-alt"></i>
                  </div>
                  <h3>Address Information</h3>
                </div>
                <div className="section-content">
                  <div className="info-grid">
                    {profileData.district && (
                      <div className="info-item">
                        <label>District</label>
                        <div className="info-value">{profileData.district}</div>
                      </div>
                    )}
                    {profileData.mandal && (
                      <div className="info-item">
                        <label>Mandal</label>
                        <div className="info-value">{profileData.mandal}</div>
                      </div>
                    )}
                    {profileData.address && (
                      <div className="info-item full-width">
                        <label>Complete Address</label>
                        <div className="info-value address-text">{profileData.address}</div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
            
            {/* Education Information */}
            {hasEducationInfo(profileData) && (
              <div className="profile-section">
                <div className="section-header">
                  <div className="section-icon education">
                    <i className="fas fa-graduation-cap"></i>
                  </div>
                  <h3>Education Information</h3>
                </div>
                <div className="section-content">
                  <div className="info-grid">
                    {profileData.institution_name && (
                      <div className="info-item">
                        <label>Institution</label>
                        <div className="info-value institution">{profileData.institution_name}</div>
                      </div>
                    )}
                    {profileData.course_name && (
                      <div className="info-item">
                        <label>Course</label>
                        <div className="info-value">{profileData.course_name}</div>
                      </div>
                    )}
                    {profileData.present_course_year && (
                      <div className="info-item">
                        <label>Current Year</label>
                        <div className="info-value year">{profileData.present_course_year}</div>
                      </div>
                    )}
                    {profileData.admission_number && (
                      <div className="info-item">
                        <label>Admission Number</label>
                        <div className="info-value admission">{profileData.admission_number}</div>
                      </div>
                    )}
                    {profileData.inst_address && (
                      <div className="info-item full-width">
                        <label>Institution Address</label>
                        <div className="info-value address-text">{profileData.inst_address}</div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
            
            {/* Bus Pass Information */}
            {hasPassInfo(profileData) && (
              <div className="profile-section">
                <div className="section-header">
                  <div className="section-icon pass">
                    <i className="fas fa-ticket-alt"></i>
                  </div>
                  <h3>Bus Pass Information</h3>
                </div>
                <div className="section-content">
                  <div className="info-grid">
                    {profileData.pass_type && (
                      <div className="info-item">
                        <label>Pass Type</label>
                        <div className="info-value type">{profileData.pass_type}</div>
                      </div>
                    )}
                    {profileData.service_type && (
                      <div className="info-item">
                        <label>Service Type</label>
                        <div className="info-value">{profileData.service_type}</div>
                      </div>
                    )}
                    {profileData.renewal_frequency && (
                      <div className="info-item">
                        <label>Renewal Frequency</label>
                        <div className="info-value">{profileData.renewal_frequency}</div>
                      </div>
                    )}
                    {profileData.created_at && (
                      <div className="info-item">
                        <label>Account Created</label>
                        <div className="info-value date">{formatDate(profileData.created_at)}</div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Verification Documents */}
            <div className="profile-section documents-section">
              <div className="section-header">
                <div className="section-icon documents">
                  <i className="fas fa-file-check"></i>
                </div>
                <h3>Verification Documents</h3>
              </div>
              <div className="section-content">
                <div className="documents-grid">
                  {/* Profile Photo */}
                  <div className="document-card">
                    <div className="document-header">
                      <i className="fas fa-id-card"></i>
                      <h4>Profile Photo</h4>
                    </div>
                    <div className="document-content">
                      {profileData.applicant_photo_filename && !imageErrors.applicant_photo ? (
                        <div className="photo-preview">
                          <img 
                            src={`http://localhost:5000/uploads/applicantPhotos/${profileData.applicant_photo_filename}`} 
                            alt="Profile" 
                            className="document-image"
                            onError={() => handleImageError('applicant_photo')}
                          />
                        </div>
                      ) : (
                        <div className="document-empty">
                          <i className="fas fa-camera"></i>
                          <span>No photo uploaded</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Study Certificate */}
                  <div className="document-card">
                    <div className="document-header">
                      <i className="fas fa-file-certificate"></i>
                      <h4>Study Certificate</h4>
                    </div>
                    <div className="document-content">
                      {profileData.study_certificate_filename || profileData.study_certificate_url ? (
                        <div className="document-actions">
                          <div className="action-buttons">
                            <a 
                              href={profileData.study_certificate_url || `http://localhost:5000/uploads/studyCertificates/${profileData.study_certificate_filename}`} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="btn-secondary"
                            >
                              <i className="fas fa-eye"></i>
                              View Document
                            </a>
                            <a 
                              href={profileData.study_certificate_url || `http://localhost:5000/uploads/studyCertificates/${profileData.study_certificate_filename}`}
                              download
                              className="btn-primary"
                            >
                              <i className="fas fa-download"></i>
                              Download
                            </a>
                          </div>
                        </div>
                      ) : (
                        <div className="document-empty">
                          <i className="fas fa-file-pdf"></i>
                          <span>No certificate uploaded</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;