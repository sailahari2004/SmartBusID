// UnifiedLogin.jsx
import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { login } from '../../services/auth';
import { useAuth } from '../../context/AuthContext';
import { useConductorAuth } from '../../context/ConductorAuthContext';
import './UnifiedLogin.css';
const UnifiedLogin = () => {
  const [formData, setFormData] = useState({
    role: 'user', // 'user', 'conductor', 'admin'
    email: '',
    conductorId: '',
    password: ''
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  
  const navigate = useNavigate();
  const { setAuthUser } = useAuth();
  const { login: conductorLogin } = useConductorAuth();

  // Move getRoleFeatures function to the top
 const getRoleFeatures = () => {
  switch (formData.role) {
    case 'user':
      return {
        features: [
          'Digital Pass Management',
          
          'Payment History'
        ],
        image: '/userimage.png'
      };
    case 'conductor':
      return {
        features: [
          'Scan QR Codes',
          'Passenger Management'
        ],
        image: '/conductorlogin.png'
      };
    case 'admin':
      return {
        features: [
          'User Management',
          'Analytics Dashboard'
          
        ],
        image: '/BUSADMIN.jpg'
      };
    default:
      return { features: [], image: '' };
  }
};
  const getRoleDescription = () => {
    switch (formData.role) {
      case 'user':
        return 'Access your digital bus pass and travel conveniently';
      case 'conductor':
        return 'Manage passengers and verify tickets efficiently';
      case 'admin':
        return 'Oversee system operations and analytics';
      default:
        return '';
    }
  };

  // Now use the function
  const roleData = getRoleFeatures();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    setError('');
  };

  const handleRoleChange = (role) => {
    setFormData(prev => ({
      ...prev,
      role,
      email: '',
      conductorId: '',
      password: ''
    }));
    setError('');
  };

  const handleUserLogin = async (email, password) => {
    const response = await login(email, password);
    
    if (response && response.declined) {
      throw new Error('Admin approval pending. Please wait.');
    } else if (response && response.token) {
      if (response.face_registered) {
        setAuthUser(response);
        navigate('/dashboard');
      } else {
        navigate('/register-face', { state: { userId: response.user_id } });
      }
    } else if (response && response.message) {
      throw new Error(response.message);
    } else {
      throw new Error('Invalid response from server');
    }
  };

  const handleConductorLogin = async (conductorId, password) => {
    const result = await conductorLogin({ conductorId, password });
    
    if (result.success) {
      navigate('/conductor/ConductorDashboard', { replace: true });
    } else {
      throw new Error(result.message || 'Login failed. Please try again.');
    }
  };

  const handleAdminLogin = async (email, password) => {
    const response = await fetch('http://localhost:5000/api/admin/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email, password }),
    });
    
    const data = await response.json();
    
    if (data.success) {
      navigate('/admin');
    } else {
      throw new Error(data.message || 'Admin login failed');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validation based on role
    if (formData.role === 'user' && (!formData.email || !formData.password)) {
      setError('Please fill in all fields');
      return;
    }
    
    if (formData.role === 'conductor' && (!formData.conductorId || !formData.password)) {
      setError('Please enter both conductor ID and password');
      return;
    }
    
    if (formData.role === 'admin' && (!formData.email || !formData.password)) {
      setError('Please fill in all fields');
      return;
    }
    
    setLoading(true);
    setError('');

    try {
      switch (formData.role) {
        case 'user':
          await handleUserLogin(formData.email, formData.password);
          break;
          
        case 'conductor':
          await handleConductorLogin(formData.conductorId, formData.password);
          break;
          
        case 'admin':
          await handleAdminLogin(formData.email, formData.password);
          break;
          
        default:
          throw new Error('Invalid role selected');
      }
    } catch (err) {
      setError(err.message || 'Login failed. Please check your credentials.');
    } finally {
      setLoading(false);
    }
  };

  const renderRoleSpecificFields = () => {
    switch (formData.role) {
      case 'user':
        return (
          <div className="form-group">
            <label htmlFor="email">Email Address</label>
            <input 
              id="email"
              name="email"
              type="email" 
              value={formData.email} 
              onChange={handleChange} 
              required 
              autoComplete="email"
              disabled={loading}
              placeholder="your@email.com"
              className="form-input"
            />
          </div>
        );
        
      case 'conductor':
        return (
          <div className="form-group">
            <label htmlFor="conductorId">Conductor ID</label>
            <input 
              id="conductorId" 
              name="conductorId"
              required 
              placeholder="Enter your conductor ID" 
              type="text" 
              value={formData.conductorId}
              autoComplete="username"
              onChange={handleChange}
              disabled={loading}
              className="form-input"
            />
          </div>
        );
        
      case 'admin':
        return (
          <div className="form-group">
            <label htmlFor="admin-email">Admin Email</label>
            <input 
              id="admin-email"
              name="email"
              type="email" 
              value={formData.email} 
              onChange={handleChange} 
              required 
              autoComplete="email"
              disabled={loading}
              placeholder="admin@buspass.com"
              className="form-input"
            />
          </div>
        );
        
      default:
        return null;
    }
  };

  return (
    <div className="unified-login-container">
      {/* Background Elements */}
      <div className="background-elements">
        <div className="floating-circle circle-1"></div>
        <div className="floating-circle circle-2"></div>
        <div className="floating-circle circle-3"></div>
      </div>

      <div className="login-grid">
        {/* Left Side - Login Form */}
        <div className="login-form-section">
          <div className="login-card">
            <div className="logo-section">
              <div className="logo-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
              </div>
              <div className="logo-text">
                <h1>Smart Bus Pass</h1>
                <p>Digital Transportation Solution</p>
              </div>
            </div>

            {/* Role Selection */}
            <div className="role-tabs">
              <button
                type="button"
                className={`role-tab ${formData.role === 'user' ? 'active' : ''}`}
                onClick={() => handleRoleChange('user')}
              >
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
                Student
              </button>
              <button
                type="button"
                className={`role-tab ${formData.role === 'conductor' ? 'active' : ''}`}
                onClick={() => handleRoleChange('conductor')}
              >
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 8v8m-4-5v5m-4-2v2m-2 4h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
                Conductor
              </button>
              <button
                type="button"
                className={`role-tab ${formData.role === 'admin' ? 'active' : ''}`}
                onClick={() => handleRoleChange('admin')}
              >
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                </svg>
                Admin
              </button>
            </div>

            {error && (
              <div className="error-message">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit} className="login-form">
              {renderRoleSpecificFields()}

              <div className="form-group">
                <label htmlFor="password">Password</label>
                <div className="password-input-container">
                  <input
                    id="password"
                    name="password"
                    type={showPassword ? "text" : "password"}
                    value={formData.password}
                    onChange={handleChange}
                    required
                    autoComplete="current-password"
                    disabled={loading}
                    placeholder="Enter your password"
                    className="form-input"
                  />
                  <button
                    type="button"
                    className="password-toggle"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? (
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" width="18" height="18">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.878 9.878L6.59 6.59m9.02 9.02l3.83 3.83" />
                      </svg>
                    ) : (
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" width="18" height="18">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                      </svg>
                    )}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="login-button"
              >
                {loading ? (
                  <>
                    <div className="loading-spinner"></div>
                    Signing In...
                  </>
                ) : (
                  <>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" width="16" height="16">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={0.8} d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" />
                    </svg>
                    Login as {formData.role.charAt(0).toUpperCase() + formData.role.slice(1)}
                  </>
                )}
              </button>
            </form>

            <div className="login-footer">
              {formData.role === 'user' && (
                <>
                  <p>
                    <Link to="/login/face" className="footer-link">Login with Face Recognition</Link>
                  </p>
                  <p>
                    Don't have an account? <Link to="/register" className="footer-link">Create Account</Link>
                  </p>
                </>
              )}
              {(formData.role === 'conductor' || formData.role === 'admin') && (
                <p>
                  <Link to="/" className="footer-link">Back to Homepage</Link>
                </p>
              )}
            </div>
          </div>
        </div>

        {/* Right Side - Role Information */}
        <div className="role-info-section">
          <div className="role-info-card">
            <div className="role-header">
              <h2>{formData.role.charAt(0).toUpperCase() + formData.role.slice(1)} Portal</h2>
              <p className="role-description">{getRoleDescription()}</p>
            </div>

            {/* Add the image section */}
            <div className="role-image-section">
              <img 
                src={roleData.image} 
                alt={`${formData.role} portal`}
                className="role-image"
              />
            </div>

            <div className="features-list">
              {roleData.features.map((feature, index) => (
                <div key={feature} className="feature-item" style={{ animationDelay: `${index * 100}ms` }}>
                  <div className="feature-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <span>{feature}</span>
                </div>
              ))}
            </div>

            
          </div>
        </div>
      </div>
    </div>
  );
};

export default UnifiedLogin;