import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import './Home.css';
import NavBar from './NavBar';

function HomePage() {
  const [isVerified, setIsVerified] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVerified(true);
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="tp-home-page">
      <NavBar/>

      {/* Hero Section */}
      <section className="tp-home-hero">
        <div className="tp-home-hero-content">
          <h1 className="tp-home-hero-title tp-home-animate-fade-in">
            Welcome to <span className="tp-home-highlight">TravelPass</span>
          </h1>
          <p className="tp-home-hero-subtitle tp-home-animate-fade-in-delay">
            Your seamless journey starts here. Experience the future of public transportation with our digital pass system.
          </p>
          <div className="tp-home-hero-buttons tp-home-animate-fade-in-delay-2">
            <Link to="/register" className="tp-home-btn tp-home-btn-primary">Get Started</Link>
            <Link to="/login" className="tp-home-btn tp-home-btn-secondary">Login</Link>
          </div>
        </div>
        <div className="tp-home-hero-visual">
          <div className="tp-home-phone-mockup">
            <div className="tp-home-phone-frame">
              <div className="tp-home-phone-screen">
                <div className="tp-home-face-recognition-animation">
                  <div className="tp-home-app-header">
                    <div className="tp-home-app-logo">TP</div>
                    <div className="tp-home-app-title">TravelPass</div>
                  </div>
                  
                  <div className="tp-home-face-scan-container">
                    <div className="tp-home-face-circle">
                      <div className="tp-home-face-silhouette">
                        <div className="tp-home-face-features">
                          <div className="tp-home-eyes">
                            <div className="tp-home-eye tp-home-left-eye"></div>
                            <div className="tp-home-eye tp-home-right-eye"></div>
                          </div>
                          <div className="tp-home-nose"></div>
                          <div className="tp-home-mouth"></div>
                        </div>
                      </div>
                      
                      <div className="tp-home-scan-animation">
                        <div className="tp-home-scan-ring tp-home-outer"></div>
                        <div className="tp-home-scan-ring tp-home-middle"></div>
                        <div className="tp-home-scan-ring tp-home-inner"></div>
                        <div className="tp-home-scan-dots">
                          <div className="tp-home-scan-dot tp-home-dot-1"></div>
                          <div className="tp-home-scan-dot tp-home-dot-2"></div>
                          <div className="tp-home-scan-dot tp-home-dot-3"></div>
                          <div className="tp-home-scan-dot tp-home-dot-4"></div>
                          <div className="tp-home-scan-dot tp-home-dot-5"></div>
                          <div className="tp-home-scan-dot tp-home-dot-6"></div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="tp-home-verification-status">
                    {!isVerified ? (
                      <>
                        <div className="tp-home-status-text">Scanning Face...</div>
                        <div className="tp-home-progress-indicator">
                          <div className="tp-home-progress-dots">
                            <div className="tp-home-dot"></div>
                            <div className="tp-home-dot"></div>
                            <div className="tp-home-dot"></div>
                          </div>
                        </div>
                      </>
                    ) : (
                      <div className="tp-home-verified-success">
                        <div className="tp-home-success-icon">
                          <div className="tp-home-checkmark"></div>
                        </div>
                        <div className="tp-home-success-text">Identity Verified</div>
                        <div className="tp-home-success-subtext">Welcome back, Alex!</div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
            <div className="tp-home-phone-shadow"></div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="tp-home-features">
        <div className="tp-home-container">
          <h2 className="tp-home-section-title">Why Choose TravelPass?</h2>
          <div className="tp-home-features-grid">
            <div className="tp-home-feature-card tp-home-animate-slide-up">
              <div className="tp-home-feature-icon">
                <div className="tp-home-icon-wrapper">
                  <span>🚌</span>
                </div>
              </div>
              <h3>Convenient Travel</h3>
              <p>Access all public transport with a single digital pass.</p>
            </div>
            <div className="tp-home-feature-card tp-home-animate-slide-up-delay-1">
              <div className="tp-home-feature-icon">
                <div className="tp-home-icon-wrapper">
                  <span>📱</span>
                </div>
              </div>
              <h3>Digital Management</h3>
              <p>Manage your pass, view history, and recharge from your phone.</p>
            </div>
            <div className="tp-home-feature-card tp-home-animate-slide-up-delay-2">
              <div className="tp-home-feature-icon">
                <div className="tp-home-icon-wrapper">
                  <span>🔐</span>
                </div>
              </div>
              <h3>Secure Authentication</h3>
              <p>Advanced face recognition technology for secure access.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Auth Options Section */}
      <section className="tp-home-auth-options">
        <div className="tp-home-container">
          <h2 className="tp-home-section-title">Get On Board</h2>
          <div className="tp-home-auth-cards">
            <div className="tp-home-auth-card">
              <div className="tp-home-card-header">
                <h3>New User</h3>
                <div className="tp-home-card-icon">👤</div>
              </div>
              <p>Create your account and register your face for seamless travel</p>
              <Link to="/register" className="tp-home-btn tp-home-btn-outline">Register Now</Link>
            </div>
            <div className="tp-home-auth-card">
              <div className="tp-home-card-header">
                <h3>Existing User</h3>
                <div className="tp-home-card-icon">🔑</div>
              </div>
              <p>Login to manage your pass, view history and more</p>
              <Link to="/login" className="tp-home-btn tp-home-btn-outline">Login</Link>
            </div>
            <div className="tp-home-auth-card">
              <div className="tp-home-card-header">
                <h3>Face Recognition</h3>
                <div className="tp-home-card-icon">👁</div>
              </div>
              <p>Experience our cutting-edge facial recognition login</p>
              <Link to="/login/face" className="tp-home-btn tp-home-btn-outline">Try Face Login</Link>
            </div>
          </div>
          
          <div className="tp-home-admin-section">
            <h3>Are you an admin or conductor?</h3>
            <div className="tp-home-admin-buttons">
              <Link to="/admin-login" className="tp-home-btn tp-home-btn-admin">Admin Login</Link>
              <Link to="/conductor-login" className="tp-home-btn tp-home-btn-conductor">Conductor Login</Link>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="tp-home-footer">
        <div className="tp-home-container">
          <p>&copy; {new Date().getFullYear()} TravelPass System. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

export default HomePage;