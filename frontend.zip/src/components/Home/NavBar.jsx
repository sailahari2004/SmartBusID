import React from 'react';
import { Link } from 'react-router-dom';
import './NavBar.css';

// Note: This component assumes the 'header-v3', 'nav-links-v3', etc., 
// styles are present in the imported CSS file.

function NavBar() {
  return (
    // Header/Navigation - Fixed and Modern
    <header className="header-v3">
      <div className="container-v3 header-container">
        <div className="logo-v3">
          <h2>TravelPass <span className="logo-icon">💳</span></h2>
        </div>
        <nav className="nav-links-v3">
          {/* Primary User Links */}
          <Link to="/login" className="nav-link-v3">Login</Link>
          <Link to="/register" className="nav-link-v3 is-cta">Register</Link>
          <Link to="/login/face" className="nav-link-v3">Face Login</Link>
          
        </nav>
      </div>
    </header>
  );
}

export default NavBar;