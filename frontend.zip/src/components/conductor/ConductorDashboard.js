import React, { useState, useEffect } from "react";
import { useConductorAuth } from "../../context/ConductorAuthContext";
import { conductorApi } from "../../services/api";
import Sidebar from "./Sidebar";
import FaceVerification from "./conductorverify";
import QRVerification from "./QRVerification";
import "./ConductorDashboard.css";

const ConductorDashboard = () => {
  const { conductor, logout } = useConductorAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [verificationMode, setVerificationMode] = useState(null);
  const [conductorProfile, setConductorProfile] = useState(null);
  const [activeTab, setActiveTab] = useState("dashboard");
  const [stats, setStats] = useState({
    totalVerifications: 0,
    faceVerifications: 0, // Renamed from passVerifications to clarify
  });
  const [verificationHistory, setVerificationHistory] = useState([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [historyError, setHistoryError] = useState("");

  // Default bus - you can set this to conductor's assigned bus
  const defaultBus = {
    _id: conductor?.assignedBusId || "default-bus-id",
    busNumber: conductor?.assignedBus || "BUS001",
    from: "City Center",
    to: "University Campus",
    route: "Main Route"
  };

  useEffect(() => {
    if (conductor) {
      fetchConductorProfile();
      fetchDashboardStats();
    }
  }, [conductor]);

  useEffect(() => {
    if (activeTab === "history") {
      fetchVerificationHistory();
    }
  }, [activeTab]);

  const fetchConductorProfile = async () => {
    try {
      // NOTE: Using a hardcoded profile for display if API fails, or just using 'conductor' object
      setConductorProfile(conductor); 
      // const response = await conductorApi.get("/auth/conductor/profile");
      // if (response.data.success) {
      //   setConductorProfile(response.data.user || response.data.conductor);
      // } else {
      //   setError("Failed to fetch conductor profile: " + response.data.message);
      // }
    } catch (error) {
      // const errorMsg = error.response?.data?.message || error.message || "Error fetching conductor profile";
      // setError(errorMsg);
    }
  };

  const fetchDashboardStats = async () => {
    try {
      const today = new Date().toISOString().split('T')[0];
      const response = await conductorApi.get(`/api/conductor/stats?date=${today}&busId=${defaultBus._id}`);
      
      if (response.data.success) {
        setStats({
          totalVerifications: response.data.stats.totalVerifications || 0,
          faceVerifications: response.data.stats.passVerifications || 0, // Assuming passVerifications are face
        });
      } else {
        await calculateStatsFromHistory();
      }
    } catch (error) {
      console.error("Error fetching stats:", error);
      await calculateStatsFromHistory();
    }
  };

  const calculateStatsFromHistory = async () => {
    try {
      const today = new Date().toISOString().split('T')[0];
      const response = await conductorApi.get(`/api/conductor/verification-history?busId=${defaultBus._id}&date=${today}`);
      
      if (response.data.success) {
        const verifications = response.data.history || [];
        
        const todayVerifications = verifications.filter(verification => {
          const verificationDate = new Date(verification.timestamp || verification.verifiedAt).toISOString().split('T')[0];
          return verificationDate === today;
        });

        const faceVerifications = todayVerifications.filter(v => 
          v.verificationType === 'face' || v.method === 'face' || !v.verificationType
        ).length;

        setStats({
          totalVerifications: todayVerifications.length,
          faceVerifications: faceVerifications,
        });
      }
    } catch (error) {
      console.error("Error calculating stats from history:", error);
      setStats({
        totalVerifications: 0,
        faceVerifications: 0,
      });
    }
  };

  const fetchVerificationHistory = async () => {
    try {
      setHistoryLoading(true);
      setHistoryError("");
      
      const today = new Date().toISOString().split('T')[0];
      const response = await conductorApi.get(
        `/api/conductor/verification-history?busId=${defaultBus._id}&date=${today}`
      );
      
      if (response.data.success) {
        const history = response.data.history || [];
        setVerificationHistory(history);
        
        updateStatsFromHistory(history);
      } else {
        setHistoryError("Failed to load verification history");
      }
    } catch (error) {
      console.error("Error fetching verification history:", error);
      setHistoryError(error.response?.data?.message || "Failed to load verification history");
    } finally {
      setHistoryLoading(false);
    }
  };

  const updateStatsFromHistory = (verifications) => {
    const today = new Date().toISOString().split('T')[0];
    
    const todayVerifications = verifications.filter(verification => {
      const verificationDate = new Date(verification.timestamp || verification.verifiedAt).toISOString().split('T')[0];
      return verificationDate === today;
    });

    const faceVerifications = todayVerifications.filter(v => 
      v.verificationType === 'face' || v.method === 'face' || !v.verificationType
    ).length;

    setStats({
      totalVerifications: todayVerifications.length,
      faceVerifications: faceVerifications,
    });
  };

  const startVerification = (mode) => {
    setVerificationMode(mode);
  };

  const handleVerificationComplete = () => {
    setVerificationMode(null);
    fetchDashboardStats();
    if (activeTab === "history") {
      fetchVerificationHistory();
    }
  };

  const formatDate = (dateString) => {
    try {
      const date = new Date(dateString);
      return date.toLocaleDateString('en-IN') + " " + date.toLocaleTimeString('en-IN', { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: true 
      });
    } catch (e) {
      return dateString;
    }
  };

  const handleLogout = () => {
    logout();
  };

  if (!conductor) {
    return (
      <div className="cbs-dashboard-container">
        <div className="cbs-loading">Loading conductor info...</div>
      </div>
    );
  }

  return (
    <div className="cbs-dashboard-container">
      {/* Sidebar is likely a separate component, but its wrapper is updated */}
      <div className="cbs-sidebar">
        <div className="cbs-sidebar-header">
          <h2>Bus Pass System</h2>
          <div className="cbs-conductor-avatar">
            <i className="fas fa-user-tie"></i>
          </div>
        </div>
        
        <div className="cbs-sidebar-tabs">
          <button 
            className={`cbs-tab-btn ${activeTab === "dashboard" ? "cbs-active" : ""}`}
            onClick={() => setActiveTab("dashboard")}
          >
            <i className="fas fa-tachometer-alt"></i>
            <span>Dashboard</span>
          </button>
          
          <button 
            className={`cbs-tab-btn ${activeTab === "history" ? "cbs-active" : ""}`}
            onClick={() => setActiveTab("history")}
          >
            <i className="fas fa-history"></i>
            <span>History</span>
          </button>
        </div>
        
        <div className="cbs-bus-info-card">
          <div className="cbs-bus-icon-large">
            <i className="fas fa-bus"></i>
          </div>
          <div className="cbs-bus-details">
            <h3>Bus {defaultBus.busNumber}</h3>
            <p>{defaultBus.from} → {defaultBus.to}</p>
            <div className="cbs-bus-status">
              <span className="cbs-status-dot cbs-online"></span>
              <span>Active</span>
            </div>
          </div>
        </div>
        
        <div className="cbs-sidebar-footer">
          <button className="cbs-logout-btn" onClick={handleLogout}>
            <i className="fas fa-sign-out-alt"></i>
            <span>Logout</span>
          </button>
        </div>
      </div>
      
      <div className="cbs-main-content">
        <header className="cbs-dashboard-header">
          <div className="cbs-header-content">
            <h1>Conductor Dashboard</h1>
            <p>Welcome back, {conductorProfile?.name || conductor.name}! Ready to verify passengers. 🚌</p>
          </div>
          <div className="cbs-user-info">
            <div className="cbs-user-details">
              <span className="cbs-user-name">{conductorProfile?.name || conductor.name}</span>
              <span className="cbs-user-role">Conductor ID: {conductorProfile?._id?.slice(-4) || 'N/A'}</span>
            </div>
            <div className="cbs-avatar">
              <i className="fas fa-user-tie"></i>
            </div>
          </div>
        </header>

        {error && (
          <div className="cbs-error-banner">
            <i className="fas fa-exclamation-circle"></i>
            <span>{error}</span>
            <button onClick={() => setError('')} className="cbs-dismiss-btn">
              <i className="fas fa-times"></i>
            </button>
          </div>
        )}

        {activeTab === "dashboard" && (
          <div className="cbs-dashboard-content">
            {/* Stats Section */}
            <div className="cbs-stats-section cbs-two-column-grid">
              <div className="cbs-stat-card cbs-total">
                <div className="cbs-stat-icon">
                  <i className="fas fa-users"></i>
                </div>
                <div className="cbs-stat-info">
                  <h3>{stats.totalVerifications}</h3>
                  <p>Total Verifications</p>
                  <span className="cbs-stat-subtitle">All methods today</span>
                </div>
              </div>
              
              <div className="cbs-stat-card cbs-face-only">
                <div className="cbs-stat-icon">
                  <i className="fas fa-id-card-alt"></i>
                </div>
                <div className="cbs-stat-info">
                  <h3>{stats.faceVerifications}</h3>
                  <p>Pass Verifications</p>
                  <span className="cbs-stat-subtitle">Face Recognition passes</span>
                </div>
              </div>
              
            </div>

            {/* Verification Options */}
            <div className="cbs-verification-section cbs-card">
              <div className="cbs-section-header">
                <h2>Passenger Verification Methods</h2>
                <p>Choose the method the passenger is using to travel.</p>
              </div>

              <div className="cbs-verification-options">
                <div className="cbs-verification-buttons">
                  <button
                    className="cbs-verification-btn cbs-face-verification"
                    onClick={() => startVerification("face")}
                  >
                    <div className="cbs-btn-icon">
                      <i className="fas fa-camera"></i>
                    </div>
                    <div className="cbs-btn-content">
                      <span className="cbs-btn-title">Face Verification </span>
                      <span className="cbs-btn-description">Verify registered pass holders using facial recognition.</span>
                    </div>
                    <div className="cbs-btn-arrow">
                      <i className="fas fa-chevron-right"></i>
                    </div>
                  </button>
                  
                  <button
                    className="cbs-verification-btn cbs-qr-verification"
                    onClick={() => startVerification("qr")}
                  >
                    <div className="cbs-btn-icon">
                      <i className="fas fa-qrcode"></i>
                    </div>
                    <div className="cbs-btn-content">
                      <span className="cbs-btn-title">QR Verification </span>
                      <span className="cbs-btn-description">Scan a one-time QR code for ticket validation.</span>
                    </div>
                    <div className="cbs-btn-arrow">
                      <i className="fas fa-chevron-right"></i>
                    </div>
                  </button>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="cbs-quick-actions cbs-card">
              <div className="cbs-section-header">
                <h2>Quick Actions</h2>
              </div>
              <div className="cbs-action-buttons">
                <button className="cbs-action-btn cbs-primary" onClick={() => setActiveTab("history")}>
                  <i className="fas fa-history"></i>
                  <span>View Today's History</span>
                </button>
                <button className="cbs-action-btn cbs-secondary" onClick={fetchDashboardStats}>
                  <i className="fas fa-sync-alt"></i>
                  <span>Refresh Stats</span>
                </button>
                <button className="cbs-action-btn cbs-danger" onClick={handleLogout}>
                  <i className="fas fa-sign-out-alt"></i>
                  <span>Logout</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {activeTab === "history" && (
          <div className="cbs-history-section">
            <div className="cbs-card">
              <div className="cbs-section-header cbs-history-header">
                <div>
                  <h2>Today's Verification History</h2>
                  <p>All passenger verification records for Bus {defaultBus.busNumber}.</p>
                </div>
                <button 
                  className="cbs-refresh-btn" 
                  onClick={fetchVerificationHistory}
                  disabled={historyLoading}
                >
                  <i className={`fas fa-sync-alt ${historyLoading ? 'fa-spin' : ''}`}></i>
                  Refresh
                </button>
              </div>
              
              {historyError && (
                <div className="cbs-error-message">
                  <i className="fas fa-exclamation-triangle"></i>
                  <div>
                    <p>Error loading history: {historyError}</p>
                    <button className="cbs-btn cbs-primary cbs-small" onClick={fetchVerificationHistory}>
                      Try Again
                    </button>
                  </div>
                </div>
              )}
              
              {historyLoading ? (
                <div className="cbs-loading-history">
                  <i className="fas fa-spinner fa-spin"></i>
                  <p>Loading verification history...</p>
                </div>
              ) : verificationHistory.length > 0 ? (
                <div className="cbs-verification-history-table">
                  <table>
                    <thead>
                      <tr>
                        <th>Passenger</th>
                        <th>Pass Type</th>
                        <th>Method</th>
                        <th>Time</th>
                        <th>Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {verificationHistory.map((verification) => (
                        <tr key={verification._id}>
                          <td>
                            <div className="cbs-passenger-info">
                              <span className="cbs-passenger-name">
                                {verification.userName || verification.passengerName || 'Unknown'}
                              </span>
                            </div>
                          </td>
                          <td>
                            <span className={`cbs-pass-type-badge ${verification.passType?.toLowerCase().replace(' ', '-') || 'general'}`}>
                              {verification.passType || 'Standard'}
                            </span>
                          </td>
                          <td>
                            <span className="cbs-verification-method-badge">
                              <i className={`fas ${verification.verificationType === 'qr' || verification.method === 'qr' ? 'fa-qrcode' : 'fa-camera'}`}></i>
                              {verification.verificationType === 'qr' || verification.method === 'qr' ? ' QR Code' : ' Face'}
                            </span>
                          </td>
                          <td>{formatDate(verification.timestamp || verification.verifiedAt)}</td>
                          <td>
                            <span className={`cbs-status-badge ${verification.status?.toLowerCase() || 'pending'}`}>
                              {verification.status || 'Pending'}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="cbs-history-placeholder">
                  <i className="fas fa-bus-alt"></i>
                  <h3>No Verifications Yet</h3>
                  <p>No successful verifications have been recorded today for this bus.</p>
                  <button className="cbs-btn cbs-primary" onClick={() => setActiveTab("dashboard")}>
                    Start Verifying
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Verification Interfaces */}
        {verificationMode === "face" && (
          <FaceVerification 
            bus={defaultBus} 
            onClose={handleVerificationComplete}
          />
        )}
        
        {verificationMode === "qr" && (
          <QRVerification 
            bus={defaultBus} 
            onClose={handleVerificationComplete}
          />
        )}
      </div>
    </div>
  );
};

export default ConductorDashboard;