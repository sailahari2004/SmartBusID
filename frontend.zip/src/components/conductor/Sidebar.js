import React, { useState } from "react";
import "./Sidebar.css";

const Sidebar = ({ buses, selectedBus, setSelectedBus, activeTab, setActiveTab }) => {
  const [searchTerm, setSearchTerm] = useState("");

  // Filter buses based on search term
  const filteredBuses = buses.filter(bus => 
    bus.busNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
    bus.route.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="sidebar">
      <div className="sidebar-header">
        <h2>Bus Pass System</h2>
      </div>
      
      <div className="sidebar-tabs">
        <button 
          className={`tab-btn ${activeTab === "dashboard" ? "active" : ""}`}
          onClick={() => setActiveTab("dashboard")}
        >
          <i className="fas fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </button>
        
        <button 
          className={`tab-btn ${activeTab === "history" ? "active" : ""}`}
          onClick={() => setActiveTab("history")}
        >
          <i className="fas fa-history"></i>
          <span>History</span>
        </button>
      </div>
      
      
      
      <div className="sidebar-footer">
        <div className="conductor-status">
          <div className="status-indicator"></div>
          <span>Online</span>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;